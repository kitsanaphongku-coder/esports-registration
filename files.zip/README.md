# ระบบลงทะเบียนทีมอีสปอร์ต 🎮

ระบบลงทะเบียนทีมแข่งขันอีสปอร์ตสำหรับ 5 เกม:
- **ROV** - 5 นักกีฬาหลัก, 2 สำรอง (ต้องมีผู้จัดการทีม, หัวหน้าทีม, โค้ช)
- **Freefire** - 4 นักกีฬาหลัก, 2 สำรอง
- **SF6** - 1 นักกีฬาหลัก
- **Tekken** - 1 นักกีฬาหลัก
- **eFootball** - 1 นักกีฬาหลัก

## วิธี Deploy ไป Vercel

### 1. Push โค้ดไป GitHub

```bash
# สร้าง repository ใหม่บน GitHub ก่อน
# จากนั้นรันคำสั่งต่อไปนี้ในโฟลเดอร์โปรเจค

git init
git add .
git commit -m "Initial commit - esports registration system"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
git push -u origin main
```

### 2. Deploy ด้วย Vercel

#### วิธีที่ 1: ผ่าน Vercel CLI
```bash
npm i -g vercel
vercel login
vercel
```

#### วิธีที่ 2: ผ่านเว็บไซต์ Vercel (แนะนำ)

1. ไปที่ [vercel.com](https://vercel.com)
2. เข้าสู่ระบบด้วย GitHub
3. คลิก "Add New Project"
4. เลือก repository ที่ push ไปแล้ว
5. คลิก "Deploy"

เท่านี้ก็เสร็จแล้ว! Vercel จะ auto-detect Next.js config และ deploy ให้อัตโนมัติ

### 3. หลัง Deploy เสร็จ

Vercel จะให้ URL มาแบบนี้:
- `https://your-project-name.vercel.app`

## เรียกใช้งานในเครื่อง (Local Development)

```bash
# ติดตั้ง dependencies
npm install

# รันเซิร์ฟเวอร์
npm run dev

# เปิดเบราว์เซอร์ไปที่
# http://localhost:3000
```

## Features

✅ เลือกเกมได้ 5 เกม  
✅ กำหนดจำนวนนักกีฬาตามเกมที่เลือก  
✅ ROV ต้องกรอก 5 นักกีฬา + ผจก./หัวหน้า/โค้ช  
✅ เกมอื่น ข้อมูลพิเศษเป็น optional  
✅ แสดงรายการทีมที่ลงทะเบียน  
✅ Responsive Design  
✅ พร้อม Deploy บน Vercel

## Tech Stack

- Next.js 14 (App Router)
- TypeScript
- Tailwind CSS
- React Hooks

---
Made with ❤️ for Esports Community
